﻿ฟอนต์ฟรีสำหรับการใช้งานส่วนตัว
แต่ถ้าต้องการใช้ในเชิงพาณิชย์
จำเป็นจะต้องซื้อฟอนต์ก่อน
สามารถซื้อฟอนต์ได้ตามลิงค์ด้านล้างนี้
-------------------------------------------------
Font free for personal use only. 
If you want commercial use
you can purchase a license 
and full set of font at link below.
-------------------------------------------------
Purchase : https://www.jipatype.com/opun
My Store : https://www.jipatype.com/
-------------------------------------------------
Contact : anupapjaichumnan@gmail.com
Donate : https://www.paypal.me/akeanupap